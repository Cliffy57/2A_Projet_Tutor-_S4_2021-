self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5478179f5e26245a45706f15249ef8c0",
    "url": "./index.html"
  },
  {
    "revision": "d2c6857b080e0a1700dc",
    "url": "./static/css/2.4253ffa8.chunk.css"
  },
  {
    "revision": "8f1dd5a5e08215949eed",
    "url": "./static/css/main.dd3d4633.chunk.css"
  },
  {
    "revision": "d2c6857b080e0a1700dc",
    "url": "./static/js/2.24ec37bc.chunk.js"
  },
  {
    "revision": "1f811fb33ed70dc90ad43fd9c87c7c0b",
    "url": "./static/js/2.24ec37bc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8f1dd5a5e08215949eed",
    "url": "./static/js/main.c524dd12.chunk.js"
  },
  {
    "revision": "6bc778b7402a685bc150",
    "url": "./static/js/runtime-main.a9adac15.js"
  },
  {
    "revision": "bb4383d624a68b509ebfbd3c80c96d8c",
    "url": "./static/media/graoully.bb4383d6.jpg"
  },
  {
    "revision": "06434e70d6d91041b6b5310f0a78c4de",
    "url": "./static/media/logo_dix-cover.06434e70.png"
  }
]);