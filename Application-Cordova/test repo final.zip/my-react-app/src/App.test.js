import React from 'react';
import { render } from '@testing-library/react';
import index from './index';

test('renders learn react link', () => {
  const { getByText } = render(<index />);
  const linkElement = getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

test('render h1 element', () => {
  render(<index />);
  expect(screen.getByText('Hello World')).toBeInTheDocument();
});