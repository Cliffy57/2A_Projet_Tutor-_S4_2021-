import React from 'react';
import ReactDOM from 'react-dom';

import { BrowserRouter as Router, Switch, Route} from "react-router-dom";

import Liste_Lieux from './components/liste_lieux';
import ajout_lieux from './components/ajout_lieux';
import 'bootstrap/dist/css/bootstrap.min.css';
import Cheat_map from './components/CheatMap';
import Footer from './components/Navigation';
import Homepage from './components/homepage';
import About from './components/about';
import Plan from './components/Plan';


const Routing = () => {
  return(
    <Router>
      
        <Switch>
          <Route exact path="/" component={Homepage} />
          <Route exact path="/home" component={Homepage} />
          <Route exact path="/about/:id" component={About} />
          <Route exact path="/map" component={Plan} />
          <Route exact path="/liste_lieux" component={Liste_Lieux}  />
          <Route exact path="/liste_lieux/:param" key={Date.now()}  component={Liste_Lieux } />
          <Route exact path='/ajout_lieux'component={ajout_lieux} />
          <Route exact path='/cheat'component={Cheat_map} />
        </Switch>
      <Footer />
    </Router>
  )
}


ReactDOM.render(
  <React.StrictMode>
    <Routing />
  </React.StrictMode>,
  document.getElementById('root')
);