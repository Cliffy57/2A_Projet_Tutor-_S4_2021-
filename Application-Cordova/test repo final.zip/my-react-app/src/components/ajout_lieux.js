import { Card, Button } from "react-bootstrap";
import { useState } from "react";
import React from "react";

import './style/ajout_lieux.css';

export default function Ajout_lieux(){

  const [site, setSite] = useState("");
  const [dscl, setDscl] = useState("");
  const [nom, setNom] = useState("");
  const [dsc, setDsc] = useState("");
  const [hor, setHor] = useState("");

  const HandleNom = event =>{
    setNom(event.target.value);
  };
  
  const HandleDsc = event =>{
    setDsc(event.target.value);
  };

  const HandleDscl = event =>{
    setDscl(event.target.value);
  };

  const HandleHor = event =>{
    setHor(event.target.value);
  };

  const HandleSite = event =>{
    setSite(event.target.value);
  };


  function Action()
  {
    if(nom === "" || dsc === "" || dscl === "" || hor === "" || site === "") {
      alert("Veuillez remplir tout les champs");
    }else{
      alert("Toutes les informations sont OK!");
    } 
  }
    
  return (
    <>
      <div className="bg_ajout">
          <h1>Ajouter un lieu</h1>

            <Card className="Card">
              <Card.Body className="BodyCard">

                <table>
                  <Card.Text className="CardNom ">
                    <td><p>Saisir un Nom :</p></td>
                    <td ><input type="text" 
                          name="nom" 
                          placeholder= "Nom du lieu" 
                          onChange={HandleNom}/></td> 
                  </Card.Text>

                  <Card.Text className="CardDsc">
                    <td><p>Saisir une Description</p></td> 
                    <td><input
                        type="text"
                        name="Dsc"
                        placeholder="Petite description courte"
                        onChange={HandleDsc}/></td>
                  </Card.Text>

                  <Card.Text className="CardDscL">
                    <td><p>Saisir une Description Longue : </p></td>
                    <td><input
                        type="text"
                        name="Dscl"
                        placeholder="Description longue "
                        onChange={HandleDscl}/></td>
                  </Card.Text>

                  <Card.Text className="CardHor">
                    <td><p>Saisir des Horaires :</p></td>  
                    <td><input type="text" 
                        name="hor" 
                        placeholder="Horaires" 
                        onChange={HandleHor}/></td> 
                  </Card.Text>

                  <Card.Text className="CardSite">
                    <td><p>Saisir un Site   :</p></td>
                    <td><input type="text" 
                        name="site" 
                        placeholder="Site internet" 
                        onChange={HandleSite}/></td>     
                  </Card.Text>
                </table>

                <Card.Text>
                  <Button className="Btn" style={{ backgroundColor:"#880C17",border:"2px white solid" }} onClick={Action} >
                    <b> Ajouter le lieu !</b>
                  </Button>
                </Card.Text>
                
              </Card.Body>
            </Card>
      </div>
    </>
  );
}
