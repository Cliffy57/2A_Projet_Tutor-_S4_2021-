import {Nav, Container} from 'react-bootstrap';
import Navbar from 'react-bootstrap/Navbar';
import {Link} from 'react-router-dom';
import React from 'react';

import logo from './images/logo_dix-cover.png';
import search from './images/search.png';
import cheat from './images/cheat.png';
import more from './images/more.png';
import map from './images/map.png';

import './style/homepage.css';

export default function Navigation() {
    return (
        <>
            <Container >
                <Navbar className="navbar" fixed="bottom"  style={{backgroundColor:"#880C17", borderTop:"2px white solid"}}>
                    <Container >
                        <Navbar.Collapse >
                            <Nav className="m-auto" >

                                <Nav.Link ><Link to="../home" className="LinkNav"><img alt="" src={logo} className="navIcon" style={{borderRadius : "50%", border : "2px solid white"}}/></Link></Nav.Link>
                                <Nav.Link ><Link to="../map" className="LinkNav"><img alt="" src={map} className="navIcon"/></Link></Nav.Link>
                                <Nav.Link ><Link to="../liste_lieux" className="LinkNav"><img alt="" src={search} className="navIcon"/></Link></Nav.Link>
                                <Nav.Link ><Link to="../ajout_lieux" className="LinkNav"><img alt="" src={more} className="navIcon"/></Link></Nav.Link>
                                <Nav.Link ><Link to="../Cheat" className="LinkNav"><img alt="" src={cheat} className="navIcon"/></Link></Nav.Link>

                            </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
            </Container>
        </>
    )
}