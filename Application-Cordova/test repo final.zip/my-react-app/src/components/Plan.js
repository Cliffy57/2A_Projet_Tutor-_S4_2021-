import { Circle, MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import { useState, useEffect, useRef } from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import {Link} from 'react-router-dom'
import React from "react";
import Axios from "axios"; //import inutile en utilisant JSON, necessaire en utilisant MySQL
import  L from 'leaflet';

import ThemeIcon from './images/dark-theme.png';
import userIcon from './images/user.png';
import DB from '../json/Lieux.json'
import "./style/Plan.css";

const fillBlueOptions = { fillColor: "blue" };

export default function MyMap() {
  
  const [colorMode, setColorMode] = useState("light");
  const [userlong, setUserlong] = useState("6");
  const [userlat, setUserlat] = useState("49");
  const [zoom , setZoom] = useState("14"); // changement de zoom via State testé, mais valeur dans la map leaflet non mutables -> idée abandonnée
  const [nom, setNom] = useState([]);
  const ref = useRef(null);

  const dark = "https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png"
  const light = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"

  useEffect(() => {
    if (ref.current) {
      ref.current.setUrl(colorMode === "light" ? light : dark);
    }
  }, [colorMode]);

  const switchTheme = () => {
    setColorMode((colorMode) => (colorMode === "light" ? "dark" : "light"));
  };
 
      
 


  // CODE A UTILISER SI ON UTILISE SERVER DISTANT ( MY SQL )
  // useEffect(() => {
  //   Axios.get("http://localhost:3001/getData").then((response) => {
  //     console.log(response.data);
  //     setNom(response.data);
  //   });
  // }, []);

  // CODE A UTILISER SI ON UTILISE DONNEES LOCALES ( JSON ) CAR SERVER PAS FONCTIONNEL SUR CORDOVA
  useEffect(()=>{
    setNom(DB);
  }, [])


  useEffect(() => {

      //Calcul de la différence entre la position de l'utilisateur et les marqueurs
    const interval = setInterval(() => {
      
      let difflat = 0;
      let difflong = 0;
      {nom.map((val) => {
        difflat = userlat - val.Latitude;
        difflong = userlong - val.Longitude;
        
        if (
          difflat > -0.002 &&
          difflong > -0.002 &&
          difflat < 0.002 &&
          difflong < 0.002
        ){
          window.navigator.vibrate(100);
        }else{}
      });
      }
    }, 1000);
    return () => clearInterval(interval);
    
  });

  useEffect(() => {
    const interval = setInterval(() => {

      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserlat(position.coords.latitude);
          setUserlong(position.coords.longitude);
        },
        function error(msg) {
          console.log(msg);
        },
        { enableHighAccuracy: true }
      );
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  
  return (
    
    <div>
      <Button  className="btn-theme " variant="outline" onClick = {switchTheme}><img alt="" src={ThemeIcon}  /></Button> 
      <MapContainer
        className="map-container"
        center={[49.1193089, 6.1757156]}
        zoom={zoom}
        style={{ height: "100vh", width: "100vw"}}>
       
        <TileLayer ref={ref} url={colorMode === "light" ? light : dark} />
     
        {nom.map((val)=>{ 
          return (
            <Marker  position={[val.Latitude,val.Longitude]} icon={L.icon({iconUrl: val.Icones,iconSize:[50,82],iconAnchor:[24,82],popupAnchor:[0,-82]})}>
              <Popup >
                <Card className="CardSetup" style={{width:'18rem'}}>
                  <Card.Body>

                    <Card.Title className="CardTitle"> 
                      {val.Nom}
                    </Card.Title>

                    <Card.Text className="CardText">
                      {val.Description}
                    </Card.Text>

                    <Card.Text>
                      <div className="CardTitle">
                        <Link to={"./about/"+val.Id} >
                          <Button variant="primary" style={{textAlign:"center"}}>
                            En savoir plus
                          </Button>
                        </Link>
                      </div>
                    </Card.Text>

                  </Card.Body>
                </Card>
              </Popup>
          </Marker>
          )
        })}

        <Marker position={[userlat, userlong]} icon={L.icon({iconUrl: userIcon ,iconSize:[50,82],iconAnchor:[24,82],popupAnchor:[0,-82]})}> 
          <Circle center={[userlat,userlong]} pathOptions={fillBlueOptions} radius={180} />
          <Popup>
            Vous êtes ici!
          </Popup>
        </Marker>

      </MapContainer>
    </div>
  );
}

