import { Circle, MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import { useState, useEffect, useRef } from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import {Link} from 'react-router-dom';
import React from "react";
import Axios from "axios"; //import inutile en utilisant JSON, necessaire en utilisant MySQL
import  L from 'leaflet';

import DB from '../json/Lieux.json'
import "./style/Cheat.css";
import userIcon from './images/user.png';

const fillBlueOptions = { fillColor: "blue" };

export default function MyMap() {
  
  const [userlong, setUserlong] = useState("6");
  const [userlat, setUserlat] = useState("49");
  const [zoom , setZoom] = useState("14"); // changement de zoom via state testé, mais valeur dans la map leaflet non mutables -> idée abandonnée
  const [nom, setNom] = useState([]);
  const ref = useRef(null);

  // CODE A UTILISER SI ON UTILISE SERVER DISTANT ( MY SQL ) CHEAT CODE PAS TESTE AVEC SERVER MAIS CA DEVRAIT FONCTIONNER
  // useEffect(() => {
  //   Axios.get("http://localhost:3001/getData").then((response) => {
  //     console.log(response.data);
  //     setNom(response.data);
  //   });
  // }, []);

  // CODE A UTILISER SI ON UTILISE DONNEES LOCALES ( JSON ) CAR SERVER PAS FONCTIONNEL SUR CORDOVA
  useEffect(()=>{
    setNom(DB);
  }, [])


  function Iut(){
      setUserlat(49.120034);
      setUserlong(6.163757);
  }
  
  function Temple(){
      setUserlat(49.120702);
      setUserlong(6.172125);
  }

  function Pompidou(){
      setUserlat(49.108241);
      setUserlong(6.181676);
  }

  function Musee(){
      setUserlat(49.121055);
      setUserlong(6.178180);
  }

  function Allemand(){
      setUserlat(49.117857);
      setUserlong(6.185319);
  }

  function Resto(){
      setUserlat(49.119540);
      setUserlong(6.172791);
  }

  function Loin(){
      setUserlat(49.127968);
      setUserlong(6.118913);
  }

  useEffect(() => {

      //Calcul de la différence entre la position de l'utilisateur et les marqueurs
    const interval = setInterval(() => {
      
      let difflat = 0;
      let difflong = 0;

      {nom.map((val) => {
        difflong = userlong - val.Longitude;
        difflat = userlat - val.Latitude;

        if (
          difflat > -0.002 &&
          difflong > -0.002 &&
          difflat < 0.002 &&
          difflong < 0.002
        ){
          console.log("Proche du lieu : "+val.Nom);
          window.navigator.vibrate(100);
        } 
        });
      }
    }, 1000);
    return () => clearInterval(interval);    
  });
  
  
  return (
    
    <div>
      <div className="cheat-btn-theme">
        <Button onClick={Iut}>IUT</Button>                <br/>
        <Button onClick={Temple}>TEMPLE </Button>         <br/>
        <Button onClick={Allemand}>PORTE ALLEMAND</Button><br/>
        <Button onClick={Musee}>COURS D'OR</Button>       <br/>
        <Button onClick={Pompidou}>POMPIDOU</Button>      <br/>
        <Button onClick={Resto}>RESTO</Button>            <br/>
        <Button onClick={Loin}>Btn Loin </Button>         <br/>
      </div>
      
      <MapContainer
        className="map-container"
        center={[49.1193089, 6.1757156]}
        zoom={zoom}
        style={{ height: "100vh", width: "100vw"}}>
       
        <TileLayer ref={ref} url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

        {nom.map((val)=>{ 
          return (
            <Marker position={[val.Latitude,val.Longitude]} >
              <Popup>

                <Card className="CardSetup" style={{width:'18rem'}}>
                  <Card.Body>

                    <Card.Title className="CardTitle"> 
                      {val.Nom}
                    </Card.Title>

                    <Card.Text className="CardText">
                      {val.Description}
                    </Card.Text>

                    <Card.Text>
                      <div className="CardTitle">
                        <Link to={"./about/"+val.Id} >
                          <Button variant="primary" style={{textAlign:"center"}}>
                            En savoir plus
                          </Button>
                        </Link>
                      </div>
                    </Card.Text>

                  </Card.Body>
                </Card>
              </Popup>
          </Marker>       
          )
        })}

        <Marker  position={[userlat, userlong]}  icon={L.icon({iconUrl: userIcon ,iconSize:[50,82],iconAnchor:[24,82],popupAnchor:[0,-82]})}> 
          <Circle center={[userlat,userlong]} pathOptions={fillBlueOptions} radius={180} />
          <Popup>
              Vous êtes ici!
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  );
}

