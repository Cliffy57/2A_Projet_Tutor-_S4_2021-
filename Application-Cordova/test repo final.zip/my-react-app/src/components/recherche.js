import { Button } from "react-bootstrap"
import {Link} from  "react-router-dom"
import { useState } from "react"
import React  from 'react'

import './style/liste_lieux.css'

    function Recherche(){
    const [terme, setTerme] = useState("");

    const handleChange = event =>{
        setTerme(event.target.value)
    };


    
    return (
        <>
            <input type="search" value={terme} onChange={handleChange} class="rounded" placeholder="Recherche" style={{marginLeft:'10px', paddingLeft:'10px'}}  />
                        <Link to={"../liste_lieux/"+terme} >

                            <Button type="button" class="primary" style={{marginLeft:'3vw'}}>Rechercher</Button>

                        </Link>
        </>
    )
}

export default Recherche;
