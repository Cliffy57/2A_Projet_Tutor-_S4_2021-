import { Card, Button } from 'react-bootstrap';
import {useEffect, useState} from 'react';
import { useParams } from 'react-router';
import parse from 'html-react-parser';
import React from 'react';
import Axios from 'axios';

import DB from '../json/Lieux.json';
import './style/about.css';

export default function About() {

    const [batiment, setBatiment] = useState([]);
    
    const { id } = useParams();

    // code fonctionnel pour base de données ( REACT PAS CORDOVA)
    // useEffect(()=>{
    //     Axios.get('http://127.0.0.1:3001/getData/'+id).then((response)=>{
         
    //         console.log(response.data);
    //         setBatiment(response.data);
            
    //       });}, []);

    // code fonctionnel pour JSON ( REACT ET CORDOVA MAIS DONNES LOCALES )
    useEffect(()=>{

        let BDD = []
        
        DB.map((val)=>{
            if (val.Id === id){
                BDD.push(val);
                
            }
            setBatiment(BDD);
        })
        
    }, [])

    return (
        <>
            <body id="bodyAbout">
                {batiment.map((val)=>{
                    
                    return(
                        <div key="aboutdiv">
                            <h1>{val.Nom} </h1>

                            <div className="CardAbout">
                                <Card className="m-auto " style={{width:'85vw',  border:'3px solid white', backgroundColor:'#880C17'}}>
                                    <Card.Body >

                                        <div className="CardImgCenter">
                                            <Card.Img variant="top" src={val.Image} className="CardAboutImg"  />
                                        </div>

                                        <Card.Text className="CardAboutHoraire ">
                                            Horaires : <br/> { parse(val.Horaire)}
                                        </Card.Text>

                                        <Card.Text className="CardAboutTxt" >
                                            {parse(val.DescriptionLongue)}
                                        </Card.Text>

                                        <Card.Text className="CardAboutSite">
                                            <Button style={{backgroundColor:"#880C17", border:"2px white solid"}}>
                                                <a href={val.Site} className="AboutSiteHREF">
                                                    Visiter le site!
                                                </a>
                                            </Button>
                                        </Card.Text>
                                        
                                    </Card.Body>
                                </Card>
                            </div>

                        </div>
                    )
                })}
            </body>
        </>
    )
}
