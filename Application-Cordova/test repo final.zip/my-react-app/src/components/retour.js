import { Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import React from 'react'

export default function Retour() {      //retour de liste lieu avec param vers list lieu sans param
    return (
        <>  
            <Link to="../liste_lieux">
                <Button style={{marginLeft:"10px"}} >Retour</Button>
            </Link>
        </>
    )
}
